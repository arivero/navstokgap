Classical spins and the dynamical meaning of an operational state — review draft

The compiled PDF is included with its standalone LaTeX source.
References and any figures are embedded; no repository files are needed.
Compile twice with a TeX installation providing Latin Modern and TikZ:
  pdflatex -no-shell-escape classical-spins-operational-closure.tex
  pdflatex -no-shell-escape classical-spins-operational-closure.tex

manifest.json records SHA-256 hashes of the source and supplied PDF.
This is an author-review draft, not an external submission.
