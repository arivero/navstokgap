Same collisions, different transport — review draft

The compiled PDF is included with its standalone LaTeX source.
References and any figures are embedded; no repository files are needed.
Compile twice with a TeX installation providing Latin Modern and TikZ:
  pdflatex -no-shell-escape same-collisions-different-transport.tex
  pdflatex -no-shell-escape same-collisions-different-transport.tex

manifest.json records SHA-256 hashes of the source and supplied PDF.
This is an author-review draft, not an external submission.
